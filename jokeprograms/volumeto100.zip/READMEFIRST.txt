TO RUN! Rename fff.exee to fff.exe
To Stop this. open the task manager, and scroll to the bottom, then kill everything that says Windows Console. it will say it will shut down your computer, it wont.
